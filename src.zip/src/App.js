import Forms from './components/Forms';
import './App.css';

function App() {
  return (
    <div>
      <Forms className='EmployeeDetails' ></Forms>
    </div>
  );
}

export default App;
