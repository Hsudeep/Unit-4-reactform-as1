import React from 'react'

const TableItem = () => {
  return (
    <div>TableItem</div>
  )
}

export default TableItem